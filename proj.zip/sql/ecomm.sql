-- 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomm`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`) VALUES
(34, 'sumsung galaxy', '374', '1.png'),
(35, 'readmi note7', '334', '2.jfif'),
(36, 'readmi note5', '294', '3.png'),
(37, 'readmi note9', '401', '4.png'),
(38, 'mi', '267', '5.png'),
(39, 'xioami mi Tv', '468', '20.jpg'),
(31, 'lenovo ideapad slim5i', '923', '6.jpg'),
(29, 'lenovo ideapad gaming3', '535', '7.jpg'),
(30, 'new vostro', '722', '8.jpg'),
(28, 'lenevo legion', '922', '9.jpg'),
(27, 'lenovo ideapad s540', '829', '10.jpg'),
(26, 'sony bravia', '1338', '11.png'),
(25, 'mi LED pro', '334', '12.png'),
(24, 'LG', '1083', '13.png'),
(23, 'Vu 4k ultra HD', '548', '14.png'),
(22, 'philips 5500 series', '280', '15.png'),
(21, 'apple ipad pro', '1217', '16.jpg'),
(20, 'apple watch series 6', '1030', '17.jpg'),
(32, 'Sony Mdr extra bass headphones', '33', '18.jpg'),
(33, 'Oneplus Q1 series', '1136', '19.jpg');
COMMIT;

